// =====================================================
// AI WATER QUALITY MONITORING DASHBOARD
// =====================================================

// =====================================================
// GLOBAL DATA
// =====================================================

let historyData = [];
let classificationChart = null;
let sensorChart = null;


// =====================================================
// HELPER
// =====================================================

function getElement(id) {
    return document.getElementById(id);
}


// =====================================================
// WATER SOURCE
// =====================================================

const sourceType = getElement("source-type");
const sourceDescription = getElement("source-description");
const currentSource = getElement("current-source");


if (sourceType) {

    sourceType.addEventListener("change", function () {

        const selectedSource = sourceType.value;

        if (currentSource) {
            currentSource.textContent = selectedSource;
        }

        if (selectedSource !== "Other" && sourceDescription) {
            sourceDescription.value = "";
        }

    });

}


// =====================================================
// LOAD LATEST READING
// =====================================================

async function loadLatestReading() {

    try {

        const response = await fetch("/latest");

        if (!response.ok) {
            throw new Error("Unable to retrieve latest reading.");
        }

        const data = await response.json();

        console.log("Latest reading loaded:", data);


        // =================================================
        // SENSOR VALUES
        // =================================================

        const phValue = getElement("ph-value");
        const tdsValue = getElement("tds-value");
        const turbidityValue = getElement("turbidity-value");
        const temperatureValue = getElement("temperature-value");


        if (phValue) {
            phValue.textContent = formatNumber(data.pH, 2);
        }

        if (tdsValue) {
            tdsValue.textContent = formatNumber(data.TDS, 1);
        }

        if (turbidityValue) {
            turbidityValue.textContent = formatNumber(
                data.Turbidity,
                2
            );
        }

        if (temperatureValue) {
            temperatureValue.textContent = formatNumber(
                data.Temperature,
                2
            );
        }


        // =================================================
        // LIVE MONITORING VALUES
        // =================================================

        const monitorPh = getElement("monitor-ph");
        const monitorTds = getElement("monitor-tds");
        const monitorTurbidity = getElement("monitor-turbidity");
        const monitorTemperature = getElement("monitor-temperature");

        if (monitorPh) {
            monitorPh.textContent = formatNumber(data.pH, 2);
        }

        if (monitorTds) {
            monitorTds.textContent = formatNumber(data.TDS, 1);
        }

        if (monitorTurbidity) {
            monitorTurbidity.textContent = formatNumber(
                data.Turbidity,
                2
            );
        }

        if (monitorTemperature) {
            monitorTemperature.textContent = formatNumber(
                data.Temperature,
                2
            );
        }


        // =================================================
        // SOURCE
        // =================================================

        const firebaseSource =
            data.source_type || "Unknown";

        const firebaseDescription =
            data.source_description || "";


        if (sourceType) {

            const validOption = Array.from(
                sourceType.options
            ).some(
                option => option.value === firebaseSource
            );

            if (validOption) {

                sourceType.value = firebaseSource;

            } else {

                sourceType.value = "Other";

            }

        }


        if (sourceDescription) {
            sourceDescription.value = firebaseDescription;
        }


        if (currentSource) {

            if (
                firebaseSource === "Other" &&
                firebaseDescription
            ) {

                currentSource.textContent =
                    firebaseDescription;

            } else {

                currentSource.textContent =
                    firebaseSource;

            }

        }


        // =================================================
        // CLASSIFICATION
        // =================================================

        const prediction =
            data.classification ||
            data.prediction ||
            "Unknown";

        const modelPrediction =
            data.model_prediction ||
            "Unknown";


        // Main AI decision
        const classification =
            getElement("classification");

        if (classification) {
            classification.textContent = prediction;
        }


        // Model prediction
        const modelPredictionElement =
            getElement("model-prediction");

        if (modelPredictionElement) {
            modelPredictionElement.textContent =
                modelPrediction;
        }


        // Final classification
        const analysisClassification =
            getElement("analysis-classification");

        if (analysisClassification) {
            analysisClassification.textContent =
                prediction;
        }


        // Source in AI Analysis
        const analysisSource =
            getElement("analysis-source");

        if (analysisSource) {

            if (
                firebaseSource === "Other" &&
                firebaseDescription
            ) {

                analysisSource.textContent =
                    firebaseDescription;

            } else {

                analysisSource.textContent =
                    firebaseSource;

            }

        }


        // Live monitoring classification
        const monitorClassification =
            getElement("monitor-classification");

        if (monitorClassification) {
            monitorClassification.textContent =
                prediction;
        }


        // =================================================
        // AI DESCRIPTION
        // =================================================

        const description =
            getElement("classification-description");

        const decisionCard =
            document.querySelector(".decision-card");


        if (prediction === "Drinkable") {

            if (description) {
                description.textContent =
                    "The AI model classified the current water-quality reading as Drinkable.";
            }

            if (decisionCard) {
                decisionCard.style.background =
                    "linear-gradient(135deg, #16a34a, #15803d)";
            }

        }

        else if (prediction === "Not Drinkable") {

            if (description) {
                description.textContent =
                    "The AI model classified the current water-quality reading as Not Drinkable.";
            }

            if (decisionCard) {
                decisionCard.style.background =
                    "linear-gradient(135deg, #dc2626, #b91c1c)";
            }

        }

        else {

            if (description) {
                description.textContent =
                    "Waiting for a valid water-quality classification.";
            }

            if (decisionCard) {
                decisionCard.style.background =
                    "linear-gradient(135deg, #2563eb, #1d4ed8)";
            }

        }


        // =================================================
        // LAST UPDATED
        // =================================================

        const updated =
            getElement("last-updated");

        if (updated) {

            if (data.timestamp) {

                const date =
                    new Date(data.timestamp);

                updated.textContent =
                    date.toLocaleString();

            } else {

                updated.textContent =
                    "Available";

            }

        }


        // =================================================
        // MODEL STATUS
        // =================================================

        const modelStatus =
            getElement("model-status");

        if (modelStatus) {
            modelStatus.textContent =
                "Ready";
        }

    }

    catch (error) {

        console.error(
            "Dashboard error:",
            error
        );


        const classification =
            getElement("classification");

        const description =
            getElement("classification-description");

        const modelPrediction =
            getElement("model-prediction");

        const analysisClassification =
            getElement("analysis-classification");

        const modelStatus =
            getElement("model-status");


        if (classification) {
            classification.textContent =
                "Connection Error";
        }

        if (description) {
            description.textContent =
                "Unable to retrieve the latest water-quality reading.";
        }

        if (modelPrediction) {
            modelPrediction.textContent =
                "--";
        }

        if (analysisClassification) {
            analysisClassification.textContent =
                "--";
        }

        if (modelStatus) {
            modelStatus.textContent =
                "Connection Error";
        }

    }

}


// =====================================================
// LOAD HISTORY
// =====================================================

async function loadHistory() {

    try {

        const response =
            await fetch("/history");

        if (!response.ok) {
            throw new Error(
                "Unable to retrieve history."
            );
        }

        const data =
            await response.json();

        historyData = Array.isArray(data)
            ? data
            : [];


        // Sort newest first
        historyData.sort(
            (a, b) => {

                const dateA =
                    new Date(a.timestamp || 0);

                const dateB =
                    new Date(b.timestamp || 0);

                return dateB - dateA;

            }
        );


        renderHistory(historyData);

        updateAnalytics(historyData);

        createCharts(historyData);

        console.log(
            "History loaded:",
            historyData
        );

    }

    catch (error) {

        console.error(
            "History error:",
            error
        );


        const historyBody =
            getElement("history-body");

        if (historyBody) {

            historyBody.innerHTML = `
                <tr>
                    <td colspan="7">
                        Unable to load history.
                    </td>
                </tr>
            `;

        }

    }

}


// =====================================================
// RENDER HISTORY TABLE
// =====================================================

// =====================================================
// RENDER HISTORY TABLE
// =====================================================

function renderHistory(data) {

    const tableBody =
        document.getElementById("history-body");


    if (!data || data.length === 0) {

        tableBody.innerHTML = `
            <tr>
                <td
                    colspan="8"
                    class="empty-state"
                >
                    No water-quality records found.
                </td>
            </tr>
        `;

        return;
    }


    tableBody.innerHTML = "";


    data.forEach(reading => {

        const row =
            document.createElement("tr");


        const timestamp =
            reading.timestamp
                ? new Date(
                    reading.timestamp
                ).toLocaleString()
                : "--";


        // Prefer the detailed source description.
        // Example: "River water" instead of "Other"
        const source =
            reading.source_description ||
            reading.source_type ||
            "Unknown";


        const classification =
            reading.classification ||
            reading.prediction ||
            "Unknown";


        let badgeClass =
            "classification-badge";


        if (classification === "Drinkable") {

            badgeClass += " drinkable";

        } else {

            badgeClass += " not-drinkable";

        }


        row.innerHTML = `

            <td>
                ${escapeHTML(timestamp)}
            </td>

            <td>
                ${escapeHTML(source)}
            </td>

            <td>
                ${formatNumber(reading.pH, 2)}
            </td>

            <td>
                ${formatNumber(reading.TDS, 1)}
            </td>

            <td>
                ${formatNumber(reading.Turbidity, 2)}
            </td>

            <td>
                ${formatNumber(reading.Temperature, 2)}
            </td>

            <td>
                <span class="${badgeClass}">
                    ${escapeHTML(classification)}
                </span>
            </td>

        `;


        tableBody.appendChild(row);

    });

}

// =====================================================
// FILTER HISTORY
// =====================================================

function filterHistory() {

    const searchElement =
        getElement("history-search");

    const filterElement =
        getElement("history-filter");


    const searchInput =
        searchElement
            ? searchElement.value
                .toLowerCase()
                .trim()
            : "";


    const classificationFilter =
        filterElement
            ? filterElement.value
            : "all";


    const filtered =
        historyData.filter(reading => {

            const source =
                (
                    reading.source_type ||
                    ""
                ).toLowerCase();


            const description =
                (
                    reading.source_description ||
                    ""
                ).toLowerCase();


            const classification =
                reading.classification ||
                reading.prediction ||
                "";


            const matchesSearch =
                source.includes(searchInput) ||
                description.includes(searchInput) ||
                classification
                    .toLowerCase()
                    .includes(searchInput);


            const matchesClassification =
                classificationFilter === "all" ||
                classification ===
                    classificationFilter;


            return (
                matchesSearch &&
                matchesClassification
            );

        });


    renderHistory(filtered);

}


// =====================================================
// ANALYTICS
// =====================================================

function updateAnalytics(data) {

    const total =
        data.length;


    const drinkable =
        data.filter(item =>
            (
                item.classification ||
                item.prediction
            ) === "Drinkable"
        ).length;


    const unsafe =
        data.filter(item =>
            (
                item.classification ||
                item.prediction
            ) === "Not Drinkable"
        ).length;


    const totalElement =
        getElement("total-readings");

    const drinkableElement =
        getElement("drinkable-count");

    const unsafeElement =
        getElement("unsafe-count");

    const latestSourceElement =
        getElement("latest-source");


    if (totalElement) {
        totalElement.textContent =
            total;
    }


    if (drinkableElement) {
        drinkableElement.textContent =
            drinkable;
    }


    if (unsafeElement) {
        unsafeElement.textContent =
            unsafe;
    }


    if (latestSourceElement) {

        if (data.length > 0) {

            latestSourceElement.textContent =
                data[0].source_type ||
                "Unknown";

        } else {

            latestSourceElement.textContent =
                "--";

        }

    }

}


// =====================================================
// CREATE CHARTS
// =====================================================

function createCharts(data) {

    createClassificationChart(data);

    createSensorChart(data);

}


// =====================================================
// CLASSIFICATION CHART
// =====================================================

function createClassificationChart(data) {

    const canvas =
        getElement("classificationChart");

    if (!canvas) {
        return;
    }


    const drinkable =
        data.filter(item =>
            (
                item.classification ||
                item.prediction
            ) === "Drinkable"
        ).length;


    const unsafe =
        data.filter(item =>
            (
                item.classification ||
                item.prediction
            ) === "Not Drinkable"
        ).length;


    if (classificationChart) {
        classificationChart.destroy();
    }


    classificationChart =
        new Chart(
            canvas,
            {
                type: "doughnut",

                data: {

                    labels: [
                        "Drinkable",
                        "Not Drinkable"
                    ],

                    datasets: [
                        {
                            data: [
                                drinkable,
                                unsafe
                            ]
                        }
                    ]

                },

                options: {

                    responsive: true,

                    maintainAspectRatio: false,

                    plugins: {

                        legend: {
                            position: "bottom"
                        }

                    }

                }

            }
        );

}


// =====================================================
// SENSOR CHART
// =====================================================

function createSensorChart(data) {

    const canvas =
        getElement("sensorChart");

    if (!canvas) {
        return;
    }


    const recent =
        data
            .slice(0, 20)
            .reverse();


    const labels =
        recent.map(item => {

            if (!item.timestamp) {
                return "";
            }

            return new Date(
                item.timestamp
            ).toLocaleTimeString();

        });


    const ph =
        recent.map(item =>
            Number(item.pH)
        );


    const tds =
        recent.map(item =>
            Number(item.TDS)
        );


    const turbidity =
        recent.map(item =>
            Number(item.Turbidity)
        );


    if (sensorChart) {
        sensorChart.destroy();
    }


    sensorChart =
        new Chart(
            canvas,
            {
                type: "line",

                data: {

                    labels: labels,

                    datasets: [

                        {
                            label: "pH",
                            data: ph,
                            tension: 0.3
                        },

                        {
                            label: "TDS",
                            data: tds,
                            tension: 0.3
                        },

                        {
                            label: "Turbidity",
                            data: turbidity,
                            tension: 0.3
                        }

                    ]

                },

                options: {

                    responsive: true,

                    maintainAspectRatio: false,

                    interaction: {

                        mode: "index",

                        intersect: false

                    },

                    plugins: {

                        legend: {
                            position: "bottom"
                        }

                    }

                }

            }
        );

}


// =====================================================
// NAVIGATION
// =====================================================

const navLinks =
    document.querySelectorAll(".nav-link");

const pageSections =
    document.querySelectorAll(".page-section");


navLinks.forEach(link => {

    link.addEventListener(
        "click",
        function(event) {

            event.preventDefault();


            const sectionId =
                this.dataset.section;


            // Active link
            navLinks.forEach(item => {

                item.classList.remove(
                    "active"
                );

            });


            this.classList.add(
                "active"
            );


            // Hide sections
            pageSections.forEach(section => {

                section.style.display =
                    "none";

                section.classList.remove(
                    "active-section"
                );

            });


            // Show selected section
            const selectedSection =
                getElement(sectionId);


            if (selectedSection) {

                selectedSection.style.display =
                    "block";

                selectedSection.classList.add(
                    "active-section"
                );

            }


            // Load history
            if (sectionId === "history") {
                loadHistory();
            }


            // Load analytics
            if (sectionId === "analytics") {
                loadHistory();
            }

        }
    );

});


// =====================================================
// HISTORY SEARCH
// =====================================================

const historySearch =
    getElement("history-search");

if (historySearch) {

    historySearch.addEventListener(
        "input",
        filterHistory
    );

}


// =====================================================
// HISTORY FILTER
// =====================================================

const historyFilter =
    getElement("history-filter");

if (historyFilter) {

    historyFilter.addEventListener(
        "change",
        filterHistory
    );

}


// =====================================================
// REFRESH BUTTON
// =====================================================

const historyRefresh =
    getElement("history-refresh");

if (historyRefresh) {

    historyRefresh.addEventListener(
        "click",
        loadHistory
    );

}


// =====================================================
// NUMBER FORMATTER
// =====================================================

function formatNumber(value, decimals) {

    if (
        value === undefined ||
        value === null ||
        value === ""
    ) {

        return "--";

    }


    const number =
        Number(value);


    if (Number.isNaN(number)) {
        return "--";
    }


    return number.toFixed(decimals);

}


// =====================================================
// HTML ESCAPE
// =====================================================

function escapeHTML(value) {

    const div =
        document.createElement("div");


    div.textContent =
        value;


    return div.innerHTML;

}


// =====================================================
// INITIAL LOAD
// =====================================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        loadLatestReading();

        loadHistory();

    }
);


// =====================================================
// AUTOMATIC LIVE REFRESH
// =====================================================

setInterval(
    loadLatestReading,
    5000
);


// =====================================================
// REFRESH HISTORY EVERY 15 SECONDS
// =====================================================

setInterval(
    loadHistory,
    15000
);