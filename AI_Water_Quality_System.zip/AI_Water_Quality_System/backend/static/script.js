let historyData = [];

let classificationChart = null;

let sensorChart = null;

let liveSensorChart = null;

let lastTimestamp = null;

let pollBusy = false;


/* =========================================================
   BASIC HELPERS
   ========================================================= */

const $ = id => document.getElementById(id);


function fmt(value, decimals = 2) {

    const n = Number(value);

    return Number.isFinite(n)
        ? n.toFixed(decimals)
        : "--";
}


function escapeHTML(value) {

    const d = document.createElement("div");

    d.textContent = value ?? "";

    return d.innerHTML;
}


/* =========================================================
   SOURCE DISPLAY
   ========================================================= */

function displaySource(type, description) {

    if (type === "Other" && description) {

        return description;

    }

    return type || "Unknown";
}


/* =========================================================
   DECISION VISUAL
   ========================================================= */

function setDecisionVisual(prediction) {

    const card =
        $("decision-card");

    const desc =
        $("classification-description");

    const icon =
        $("decision-icon");

    const status =
        $("classification");

    const monitor =
        $("monitor-classification");

    const analysisStatus =
        $("analysis-status");


    status.textContent =
        prediction || "Waiting for reading...";


    monitor.textContent =
        prediction || "Waiting...";


    analysisStatus.textContent =
        prediction || "Waiting";


    if (prediction === "Drinkable") {

        card.style.background =
            "linear-gradient(135deg,#15803d,#166534)";

        desc.textContent =
            "The Decision Tree model classified the current water-quality reading as Drinkable.";

        icon.textContent = "✓";


    } else if (
        prediction === "Non-Drinkable"
    ) {

        card.style.background =
            "linear-gradient(135deg,#b91c1c,#991b1b)";

        desc.textContent =
            "The Decision Tree model classified the current water-quality reading as Non-Drinkable.";

        icon.textContent = "!";


    } else {

        card.style.background =
            "linear-gradient(135deg,#172f54,#0e2749)";

        desc.textContent =
            "Waiting for a valid water-quality classification.";

        icon.textContent = "💧";

    }
}


/* =========================================================
   SENSOR STATUS
   ========================================================= */

function updateSensorStatus() {

    [
        "ph-status",
        "tds-status",
        "turbidity-status",
        "temperature-status"
    ].forEach(id => {

        if ($(id)) {

            $(id).textContent = "LIVE";

        }

    });
}


/* =========================================================
   FRESHNESS
   ========================================================= */

function updateFreshness(timestamp) {

    if (!timestamp) {

        $("freshness").textContent = "--";

        return;

    }


    const ms =
        Date.now() -
        new Date(timestamp).getTime();


    if (!Number.isFinite(ms)) {

        $("freshness").textContent = "--";

        return;

    }


    const sec =
        Math.max(
            0,
            Math.round(ms / 1000)
        );


    $("freshness").textContent =
        sec <= 5
            ? "Fresh"
            : `${sec}s ago`;


    const stale =
        sec > 15;


    $("sensor-health").textContent =
        stale
            ? "Stale"
            : "Receiving";


    $("health-badge").textContent =
        stale
            ? "CHECK"
            : "ONLINE";


    $("health-badge").style.background =
        stale
            ? "#fff7ed"
            : "#ecfdf3";


    $("health-badge").style.color =
        stale
            ? "#c2410c"
            : "#15803d";
}


/* =========================================================
   APPLY SOURCE TO UI
   ========================================================= */

function applySourceToUI(
    type,
    description
) {

    const source =
        type || "Tap Water";


    if ($("source-type")) {

        const exists =
            [
                ...$("source-type").options
            ].some(
                o => o.value === source
            );


        $("source-type").value =
            exists
                ? source
                : "Other";

    }


    if ($("source-description")) {

        $("source-description").value =
            description || "";

    }


    if ($("other-source-group")) {

        $("other-source-group").style.display =
            source === "Other"
                ? "grid"
                : "none";

    }


    if ($("current-source")) {

        $("current-source").textContent =
            displaySource(
                source,
                description
            );

    }
}


/* =========================================================
   SAVE SOURCE
   ========================================================= */

async function saveSource() {

    const sourceType =
        $("source-type")?.value ||
        "Tap Water";


    const description =
        $("source-description")?.value
            .trim() || "";


    const status =
        $("source-save-status");


    if (
        sourceType === "Other" &&
        !description
    ) {

        status.textContent =
            "Add a description for Other.";

        status.className =
            "inline-status error";

        return;

    }


    try {

        const response =
            await fetch(
                "/set-source",
                {

                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({

                        source_type:
                            sourceType,

                        source_description:
                            description

                    })

                }
            );


        if (!response.ok) {

            throw new Error(
                "Source endpoint unavailable"
            );

        }


        // ----------------------------------------------------
        // IMPORTANT:
        // Update UI ONLY after successful save.
        // ----------------------------------------------------

        applySourceToUI(
            sourceType,
            description
        );


        status.textContent =
            "Source saved successfully";


        status.className =
            "inline-status success";


        setTimeout(() => {

            status.textContent =
                "Ready";

            status.className =
                "inline-status";

        }, 2500);


        // ----------------------------------------------------
        // Refresh History.
        //
        // We DO NOT call loadLatestReading() here because
        // the latest-reading polling must not control the
        // source selector.
        // ----------------------------------------------------

        await loadHistory();


    } catch (error) {

        status.textContent =
            "Could not save source";


        status.className =
            "inline-status error";


        console.error(
            "Save source error:",
            error
        );

    }
}


/* =========================================================
   LOAD LATEST READING
   ========================================================= */

async function loadLatestReading(
    showError = true
) {

    if (pollBusy) return;

    pollBusy = true;


    try {

        const response =
            await fetch(
                "/latest",
                {
                    cache: "no-store"
                }
            );


        if (!response.ok) {

            throw new Error(
                "Latest endpoint returned an error"
            );

        }


        const data =
            await response.json();


        if (data.error) {

            throw new Error(
                data.error
            );

        }


        // ----------------------------------------------------
        // Sensor values
        // ----------------------------------------------------

        $("ph-value").textContent =
            fmt(data.pH, 2);


        $("tds-value").textContent =
            fmt(data.TDS, 1);


        $("turbidity-value").textContent =
            fmt(data.Turbidity, 2);


        $("temperature-value").textContent =
            fmt(data.Temperature, 2);


        $("monitor-ph").textContent =
            fmt(data.pH, 2);


        $("monitor-tds").textContent =
            fmt(data.TDS, 1);


        $("monitor-turbidity").textContent =
            fmt(data.Turbidity, 2);


        $("monitor-temperature").textContent =
            fmt(data.Temperature, 2);


        // ----------------------------------------------------
        // Classification
        // ----------------------------------------------------

        const prediction =
            data.classification ||
            data.prediction ||
            "Unknown";


        const modelPrediction =
            data.model_prediction ||
            "Unknown";


        // ----------------------------------------------------
        // Source
        //
        // IMPORTANT:
        // We READ the source for displaying information,
        // but we DO NOT change the dropdown here.
        //
        // This fixes the source jumping problem.
        // ----------------------------------------------------

        const source =
            displaySource(
                data.source_type,
                data.source_description
            );


        $("model-prediction").textContent =
            modelPrediction;


        $("model-prediction-2").textContent =
            modelPrediction;


        $("analysis-classification").textContent =
            prediction;


        $("analysis-source").textContent =
            source;


        $("analysis-source-2").textContent =
            source;


        $("model-health").textContent =
            "Ready";


        $("firebase-health").textContent =
            "Connected";


        $("sidebar-system-status").textContent =
            "System Online";


        $("sidebar-firebase-status").textContent =
            "Firebase Connected";


        setDecisionVisual(
            prediction
        );


        updateSensorStatus();


        // ----------------------------------------------------
        // Timestamp
        // ----------------------------------------------------

        if (data.timestamp) {

            lastTimestamp =
                data.timestamp;


            $("last-updated").textContent =
                new Date(
                    data.timestamp
                ).toLocaleString();


            updateFreshness(
                data.timestamp
            );

        }


        // ----------------------------------------------------
        // Classification status
        // ----------------------------------------------------

        if (
            prediction === "Drinkable"
        ) {

            $("analysis-status").textContent =
                "Drinkable";


        } else if (
            prediction === "Non-Drinkable"
        ) {

            $("analysis-status").textContent =
                "Non-Drinkable";

        }


        // ----------------------------------------------------
        // Live chart
        // ----------------------------------------------------

        if (data.values_changed) {

            updateLiveChart(
                data
            );

        }


    } catch (error) {

        console.error(
            "Latest reading:",
            error
        );


        if (showError) {

            $("model-health").textContent =
                "Unavailable";


            $("sensor-health").textContent =
                "Connection error";


            $("health-badge").textContent =
                "OFFLINE";


            $("health-badge").style.background =
                "#fef2f2";


            $("health-badge").style.color =
                "#b91c1c";

        }


    } finally {

        pollBusy = false;

    }
}


/* =========================================================
   RENDER HISTORY
   ========================================================= */

function renderHistory(data) {

    const body =
        $("history-body");


    if (!data.length) {

        body.innerHTML =
            `<tr>
                <td colspan="7" class="empty">
                    No water-quality records found.
                </td>
            </tr>`;

        return;

    }


    body.innerHTML =
        data.map(r => {

            const classification =
                r.classification ||
                r.prediction ||
                "Unknown";


            const cls =
                classification === "Drinkable"
                    ? "drinkable"
                    : "non-drinkable";


            const source =
                displaySource(
                    r.source_type,
                    r.source_description
                );


            return `
                <tr>

                    <td>
                        ${escapeHTML(
                            r.timestamp
                                ? new Date(
                                    r.timestamp
                                ).toLocaleString()
                                : "--"
                        )}
                    </td>

                    <td>
                        ${escapeHTML(source)}
                    </td>

                    <td>
                        ${fmt(r.pH, 2)}
                    </td>

                    <td>
                        ${fmt(r.TDS, 1)}
                    </td>

                    <td>
                        ${fmt(r.Turbidity, 2)}
                    </td>

                    <td>
                        ${fmt(r.Temperature, 2)}
                    </td>

                    <td>
                        <span class="class-badge ${cls}">
                            ${escapeHTML(
                                classification
                            )}
                        </span>
                    </td>

                </tr>
            `;

        }).join("");

}


/* =========================================================
   SOURCE FILTER
   ========================================================= */

function populateSourceFilter() {

    const select =
        $("history-source-filter");


    const current =
        select.value;


    const sources =
        [
            ...new Set(

                historyData

                    .map(
                        r =>
                            displaySource(
                                r.source_type,
                                r.source_description
                            )
                    )

                    .filter(Boolean)

            )

        ].sort();


    select.innerHTML =
        `<option value="all">
            All sources
        </option>` +

        sources
            .map(
                s =>
                    `<option value="${escapeHTML(s)}">
                        ${escapeHTML(s)}
                    </option>`
            )
            .join("");


    if (
        sources.includes(current)
    ) {

        select.value =
            current;

    }
}


/* =========================================================
   FILTER HISTORY
   ========================================================= */

function filterHistory() {

    const q =
        (
            $("history-search").value ||
            ""
        )
        .toLowerCase()
        .trim();


    const c =
        $("history-filter").value;


    const s =
        $("history-source-filter").value;


    const filtered =
        historyData.filter(r => {

            const source =
                displaySource(
                    r.source_type,
                    r.source_description
                );


            const classification =
                r.classification ||
                r.prediction ||
                "";


            const matchesQ =
                !q ||
                source
                    .toLowerCase()
                    .includes(q) ||
                classification
                    .toLowerCase()
                    .includes(q);


            const matchesC =
                c === "all" ||
                classification === c;


            const matchesS =
                s === "all" ||
                source === s;


            return (
                matchesQ &&
                matchesC &&
                matchesS
            );

        });


    renderHistory(
        filtered
    );
}


/* =========================================================
   LOAD HISTORY
   ========================================================= */

async function loadHistory() {

    try {

        const response =
            await fetch(
                "/history",
                {
                    cache: "no-store"
                }
            );


        if (!response.ok) {

            throw new Error(
                "History endpoint returned an error"
            );

        }


        const data =
            await response.json();


        if (
            data &&
            !Array.isArray(data) &&
            data.error
        ) {

            throw new Error(
                data.error
            );

        }


        historyData =
            Array.isArray(data)
                ? data
                : [];


        historyData.sort(
            (a, b) =>
                new Date(
                    b.timestamp || 0
                ) -
                new Date(
                    a.timestamp || 0
                )
        );


        populateSourceFilter();

        filterHistory();

        updateAnalytics();

        renderRecentActivity();

        createCharts();


    } catch (error) {

        console.error(
            "History:",
            error
        );


        $("history-body").innerHTML =
            `<tr>
                <td colspan="7" class="empty">
                    Unable to load history.
                </td>
            </tr>`;

    }
}


/* =========================================================
   ANALYTICS
   ========================================================= */

function updateAnalytics() {

    const total =
        historyData.length;


    const drink =
        historyData.filter(
            r =>
                (
                    r.classification ||
                    r.prediction
                ) === "Drinkable"
        ).length;


    const non =
        historyData.filter(
            r =>
                (
                    r.classification ||
                    r.prediction
                ) === "Non-Drinkable"
        ).length;


    $("total-readings").textContent =
        total;


    $("drinkable-count").textContent =
        drink;


    $("unsafe-count").textContent =
        non;


    $("latest-source").textContent =
        total
            ? displaySource(
                historyData[0].source_type,
                historyData[0].source_description
            )
            : "--";
}


/* =========================================================
   RECENT ACTIVITY
   ========================================================= */

function renderRecentActivity() {

    const el =
        $("recent-activity");


    const rows =
        historyData.slice(
            0,
            5
        );


    if (!rows.length) {

        el.innerHTML =
            `<div class="empty">
                No readings recorded yet.
            </div>`;

        return;

    }


    el.innerHTML =
        rows.map(r => {

            const c =
                r.classification ||
                r.prediction ||
                "Unknown";


            const badge =
                c === "Drinkable"
                    ? "drink"
                    : "not";


            return `
                <div class="activity">

                    <time>
                        ${
                            r.timestamp
                                ? new Date(
                                    r.timestamp
                                ).toLocaleTimeString()
                                : "--"
                        }
                    </time>

                    <strong>
                        ${escapeHTML(
                            displaySource(
                                r.source_type,
                                r.source_description
                            )
                        )}
                    </strong>

                    <span class="badge ${badge}">
                        ${escapeHTML(c)}
                    </span>

                </div>
            `;

        }).join("");

}


/* =========================================================
   CHART DATA
   ========================================================= */

function chartData() {

    const recent =
        historyData
            .slice(0, 25)
            .reverse();


    return {

        labels:
            recent.map(
                r =>
                    r.timestamp
                        ? new Date(
                            r.timestamp
                        ).toLocaleTimeString()
                        : ""
            ),


        ph:
            recent.map(
                r =>
                    Number(r.pH)
            ),


        tds:
            recent.map(
                r =>
                    Number(r.TDS)
            ),


        turbidity:
            recent.map(
                r =>
                    Number(r.Turbidity)
            )

    };
}


/* =========================================================
   CREATE CHARTS
   ========================================================= */

function createCharts() {

    const c =
        chartData();


    if (classificationChart) {

        classificationChart.destroy();

    }


    classificationChart =
        new Chart(
            $("classificationChart"),
            {

                type: "doughnut",

                data: {

                    labels: [
                        "Drinkable",
                        "Non-Drinkable"
                    ],

                    datasets: [

                        {

                            data: [

                                historyData.filter(
                                    r =>
                                        (
                                            r.classification ||
                                            r.prediction
                                        ) === "Drinkable"
                                ).length,


                                historyData.filter(
                                    r =>
                                        (
                                            r.classification ||
                                            r.prediction
                                        ) === "Non-Drinkable"
                                ).length

                            ]

                        }

                    ]

                },

                options: {

                    responsive: true,

                    maintainAspectRatio: false,

                    plugins: {

                        legend: {

                            position:
                                "bottom"

                        }

                    }

                }

            }
        );


    if (sensorChart) {

        sensorChart.destroy();

    }


    sensorChart =
        new Chart(
            $("sensorChart"),
            {

                type: "line",

                data: {

                    labels:
                        c.labels,

                    datasets: [

                        {
                            label: "pH",
                            data: c.ph,
                            tension: 0.35
                        },

                        {
                            label: "TDS",
                            data: c.tds,
                            tension: 0.35
                        },

                        {
                            label: "Turbidity",
                            data: c.turbidity,
                            tension: 0.35
                        }

                    ]

                },

                options: {

                    responsive: true,

                    maintainAspectRatio: false,

                    interaction: {

                        mode: "index",

                        intersect: false

                    }

                }

            }
        );

}


/* =========================================================
   LIVE CHART
   ========================================================= */

function updateLiveChart(data) {

    if (!liveSensorChart) {

        liveSensorChart =
            new Chart(
                $("liveSensorChart"),
                {

                    type: "line",

                    data: {

                        labels: [],

                        datasets: [

                            {
                                label: "pH",
                                data: [],
                                tension: 0.35
                            },

                            {
                                label: "TDS",
                                data: [],
                                tension: 0.35
                            },

                            {
                                label: "Turbidity",
                                data: [],
                                tension: 0.35
                            }

                        ]

                    },

                    options: {

                        responsive: true,

                        maintainAspectRatio: false,

                        animation: false,

                        interaction: {

                            mode: "index",

                            intersect: false

                        }

                    }

                }
            );

    }


    const chart =
        liveSensorChart;


    const label =
        data.timestamp
            ? new Date(
                data.timestamp
            ).toLocaleTimeString()
            : "now";


    chart.data.labels.push(
        label
    );


    chart.data.datasets[0].data.push(
        Number(data.pH)
    );


    chart.data.datasets[1].data.push(
        Number(data.TDS)
    );


    chart.data.datasets[2].data.push(
        Number(data.Turbidity)
    );


    if (
        chart.data.labels.length > 20
    ) {

        chart.data.labels.shift();


        chart.data.datasets.forEach(
            d =>
                d.data.shift()
        );

    }


    chart.update(
        "none"
    );
}


/* =========================================================
   EXPORT CSV
   ========================================================= */

function exportCSV() {

    if (!historyData.length) {

        return;

    }


    const header = [

        "Date / Time",

        "Source",

        "pH",

        "TDS",

        "Turbidity",

        "Temperature",

        "Classification"

    ];


    const rows =
        historyData.map(
            r => [

                r.timestamp
                    ? new Date(
                        r.timestamp
                    ).toLocaleString()
                    : "",

                displaySource(
                    r.source_type,
                    r.source_description
                ),

                r.pH,

                r.TDS,

                r.Turbidity,

                r.Temperature,

                r.classification ||
                r.prediction ||
                ""

            ]
        );


    const csv =
        [
            header,
            ...rows
        ]
        .map(
            row =>
                row
                    .map(
                        v =>
                            `"${String(v)
                                .replaceAll(
                                    '"',
                                    '""'
                                )}"`
                    )
                    .join(",")
        )
        .join("\n");


    const blob =
        new Blob(
            [csv],
            {
                type:
                    "text/csv;charset=utf-8"
            }
        );


    const url =
        URL.createObjectURL(
            blob
        );


    const a =
        document.createElement(
            "a"
        );


    a.href =
        url;


    a.download =
        `water_quality_history_${
            new Date()
                .toISOString()
                .slice(0, 10)
        }.csv`;


    a.click();


    URL.revokeObjectURL(
        url
    );
}


/* =========================================================
   NAVIGATION
   ========================================================= */

function setupNavigation() {

    document
        .querySelectorAll(
            ".nav-link"
        )
        .forEach(
            link => {

                link.addEventListener(
                    "click",
                    e => {

                        e.preventDefault();


                        const id =
                            link.dataset.section;


                        document
                            .querySelectorAll(
                                ".nav-link"
                            )
                            .forEach(
                                x =>
                                    x.classList.remove(
                                        "active"
                                    )
                            );


                        link.classList.add(
                            "active"
                        );


                        document
                            .querySelectorAll(
                                ".page-section"
                            )
                            .forEach(
                                s =>
                                    s.classList.remove(
                                        "active"
                                    )
                            );


                        $(id).classList.add(
                            "active"
                        );


                        history.replaceState(
                            null,
                            "",
                            `#${id}`
                        );


                        if (
                            id === "analytics"
                        ) {

                            createCharts();

                        }

                    }
                );

            }
        );


    document
        .querySelectorAll(
            "[data-go='history']"
        )
        .forEach(
            btn =>
                btn.addEventListener(
                    "click",
                    () => {

                        document
                            .querySelector(
                                "[data-section='history']"
                            )
                            .click();

                    }
                )
        );

}


/* =========================================================
   EVENTS
   ========================================================= */

function setupEvents() {

    $("source-type")
        .addEventListener(
            "change",
            () => {

                const other =
                    $("source-type").value ===
                    "Other";


                $("other-source-group")
                    .style.display =
                        other
                            ? "grid"
                            : "none";


                if (!other) {

                    $("source-description")
                        .value = "";

                }


                $("current-source")
                    .textContent =
                        other
                            ? "Other"
                            : $("source-type").value;

            }
        );


    $("save-source")
        .addEventListener(
            "click",
            saveSource
        );


    $("history-search")
        .addEventListener(
            "input",
            filterHistory
        );


    $("history-filter")
        .addEventListener(
            "change",
            filterHistory
        );


    $("history-source-filter")
        .addEventListener(
            "change",
            filterHistory
        );


    $("history-refresh")
        .addEventListener(
            "click",
            loadHistory
        );


    $("export-csv")
        .addEventListener(
            "click",
            exportCSV
        );

}


/* =========================================================
   INITIALIZATION
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    async () => {

        setupNavigation();

        setupEvents();


        // ----------------------------------------------------
        // Load latest reading
        // ----------------------------------------------------

        await loadLatestReading();


        // ----------------------------------------------------
        // Load History
        // ----------------------------------------------------

        await loadHistory();


        // ----------------------------------------------------
        // Restore requested section from URL
        // ----------------------------------------------------

        const hash =
            location.hash.replace(
                "#",
                ""
            );


        if (
            hash &&
            $(hash) &&
            document.querySelector(
                `[data-section="${hash}"]`
            )
        ) {

            document
                .querySelector(
                    `[data-section="${hash}"]`
                )
                .click();

        }


        // ----------------------------------------------------
        // Poll LIVE sensor data
        //
        // This refreshes sensor values only.
        // It does NOT change the source selector.
        // ----------------------------------------------------

        setInterval(
            () =>
                loadLatestReading(false),
            2000
        );


        // ----------------------------------------------------
        // Refresh History
        // ----------------------------------------------------

        setInterval(
            loadHistory,
            10000
        );

    }
);